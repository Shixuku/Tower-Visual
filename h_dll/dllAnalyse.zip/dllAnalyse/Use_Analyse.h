
#ifndef USE_Analyse_H
#define USE_Analyse_H

#ifdef _DEBUG
#include "E:/dllAnalyse/lib_debug/comment_lib.txt"
#else
#include "E:/dllAnalyse/lib_release/comment_lib.txt"
#endif // DEBUGE


#endif //USE_Analyse_H